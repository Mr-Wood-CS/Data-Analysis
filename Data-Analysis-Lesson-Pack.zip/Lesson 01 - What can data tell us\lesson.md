﻿# Lesson 1: What can data tell us?

**Time:** 45 minutes · **Skills:** CSV, records, fields, read_csv and head

## Learning intention

Describe what one row represents and load a CSV into a DataFrame.

**Success criteria:** I can identify the record identifier, explain two fields, and run code that displays five records.

## Get ready

[Starter Python](resources/starters/lesson01.py) · [CSV](resources/datasets/gaming.csv) · [Data dictionary](reference/data-dictionary.md)

Open the starter in your extracted pack. Save your own copy in the same starters folder with your initials in the filename. Run it using your editor, or `python resources/starters/lesson01.py` from the pack folder. Printed results appear in the terminal; saved files go to `resources/generated/`. See [setup](setup.md) if Python cannot find Pandas. Do not edit the raw CSV.

## Lesson route

| Minutes | Activity | What to do |
| --- | --- | --- |
| 0–5 | Retrieve and predict | A club has a sheet of scores. What is the difference between a question and a piece of data? |
| 5–13 | Model and explain | A CSV stores a table as text. A record is one row; a field is one column. Here one record is a fictional player summary, not a single match. player_id is a unique identifier. A DataFrame is Pandas’ table structure. Show import, the variable df, a function call and the dot in df.head(). Explain that df is a chosen variable name. |
| 13–23 | Guided practice | Trace the model code, predict one output, then run it. Discuss the hinge question before progressing. |
| 23–38 | Apply independently | Complete the three core tasks. Save code and evidence; use support or stretch as appropriate. |
| 38–43 | Explain and review | Compare one result with a partner and justify a method or limitation. |
| 43–45 | Exit check | Name the identifier and explain why this dataset cannot prove that gaming improves schoolwork. |

## Key idea

A CSV stores a table as text. A record is one row; a field is one column. Here one record is a fictional player summary, not a single match. player_id is a unique identifier. A DataFrame is Pandas’ table structure. Show import, the variable df, a function call and the dot in df.head(). Explain that df is a chosen variable name.

## Worked model

The starter has already loaded `gaming.csv` as `df`, imported Pandas as `pd`, and defined the output folder `OUT`. Chart starters also import `plt`.

```python
print(df.head())
print(df.shape)
print(df.columns.tolist())
```

Before running: predict one output. After running: explain one line to your partner. Python field names and game labels must match exactly.

## Your investigation

1. Predict what head() will show, then run the starter. Identify the first player and the first game.

2. Find the number of records and fields using shape. Explain why the header is not a player record.

3. Write two questions the table could answer and one it cannot answer. Name the fields needed for each answerable question.

## Support

Give a printed six-row table. Highlight one whole record and trace player_id to the screen. Offer the sentence: One row represents ___.

## Stretch

Explain why score alone is not a safe identifier. Suggest a field needed to compare improvement over time.

## Stop and check

Does shape[0] count columns or rows? Show with a three-row, two-column paper table.

## Save your evidence

Save your edited script and a short Markdown note containing your question, one result with units or denominator, an explanation of a key line, and any help used. For charts, include the PNG and a text description. Keep numerical results in your note rather than relying only on a screenshot.

## Exit ticket

Name the identifier and explain why this dataset cannot prove that gaming improves schoolwork.

