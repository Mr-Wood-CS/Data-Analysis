﻿# Lesson 3: Filtering records

**Time:** 45 minutes · **Skills:** Boolean masks with >, < and ==

## Learning intention

Select records that meet a single condition.

**Success criteria:** I can predict a mask, filter records, and distinguish > from >=.

## Get ready

[Starter Python](resources/starters/lesson03.py) · [CSV](resources/datasets/gaming.csv) · [Data dictionary](reference/data-dictionary.md)

Open the starter in your extracted pack. Save your own copy in the same starters folder with your initials in the filename. Run it using your editor, or `python resources/starters/lesson03.py` from the pack folder. Printed results appear in the terminal; saved files go to `resources/generated/`. See [setup](setup.md) if Python cannot find Pandas. Do not edit the raw CSV.

## Lesson route

| Minutes | Activity | What to do |
| --- | --- | --- |
| 0–5 | Retrieve and predict | What is the maximum score? Does that identify a player? |
| 5–13 | Model and explain | A comparison creates one True/False value per row. Putting that mask inside df[...] keeps True rows. Demonstrate score > 80; test the boundary value 80 on paper. Python uses == for comparison and = for assignment. |
| 13–23 | Guided practice | Trace the model code, predict one output, then run it. Discuss the hinge question before progressing. |
| 23–38 | Apply independently | Complete the three core tasks. Save code and evidence; use support or stretch as appropriate. |
| 38–43 | Explain and review | Compare one result with a partner and justify a method or limitation. |
| 43–45 | Exit check | Write a filter for minutes below 20 and explain True in its mask. |

## Key idea

A comparison creates one True/False value per row. Putting that mask inside df[...] keeps True rows. Demonstrate score > 80; test the boundary value 80 on paper. Python uses == for comparison and = for assignment.

## Worked model

The starter has already loaded `gaming.csv` as `df`, imported Pandas as `pd`, and defined the output folder `OUT`. Chart starters also import `plt`.

```python
mask = df["score"] > 80
print(mask.head())
selected = df[mask]
print(selected[["player_id", "score"]])
print("Records", len(selected))
```

Before running: predict one output. After running: explain one line to your partner. Python field names and game labels must match exactly.

## Your investigation

1. Predict whether a score of exactly 80 is selected, then test your explanation against the table.

2. Select players scoring at least 80. Display player_id and score.

3. Select the records for Block Quest. Count them and explain the comparison operator.

## Support

Provide df[df["game"] == "Block Quest"] and ask pupils to annotate each part before adapting it.

## Stretch

Find scores between two bounds by first applying one filter, then another. Save both stages.

## Stop and check

Which condition includes 80: > 80 or >= 80?

## Save your evidence

Save your edited script and a short Markdown note containing your question, one result with units or denominator, an explanation of a key line, and any help used. For charts, include the PNG and a text description. Keep numerical results in your note rather than relying only on a screenshot.

## Exit ticket

Write a filter for minutes below 20 and explain True in its mask.

