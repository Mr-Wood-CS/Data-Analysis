﻿# Lesson 9: Bar charts that answer questions

**Time:** 45 minutes · **Skills:** Bar charts, labels and saving PNG

## Learning intention

Represent category counts accurately.

**Success criteria:** I can save a labelled bar chart and describe the values it represents.

## Get ready

[Starter Python](resources/starters/lesson09.py) · [CSV](resources/datasets/gaming.csv) · [Data dictionary](reference/data-dictionary.md)

Open the starter in your extracted pack. Save your own copy in the same starters folder with your initials in the filename. Run it using your editor, or `python resources/starters/lesson09.py` from the pack folder. Printed results appear in the terminal; saved files go to `resources/generated/`. See [setup](setup.md) if Python cannot find Pandas. Do not edit the raw CSV.

## Lesson route

| Minutes | Activity | What to do |
| --- | --- | --- |
| 0–5 | Retrieve and predict | Why keep a raw CSV after cleaning? |
| 5–13 | Model and explain | Summarise before plotting. Put categories on the horizontal axis and player counts on the vertical axis. Use a zero baseline for these bars because lengths encode magnitude. A clear title describes the fictional sample; labels explain units. The scripts save PNG files so they work without a pop-up window. |
| 13–23 | Guided practice | Trace the model code, predict one output, then run it. Discuss the hinge question before progressing. |
| 23–38 | Apply independently | Complete the three core tasks. Save code and evidence; use support or stretch as appropriate. |
| 38–43 | Explain and review | Compare one result with a partner and justify a method or limitation. |
| 43–45 | Exit check | State a question answered by your chart and one it does not answer. |

## Key idea

Summarise before plotting. Put categories on the horizontal axis and player counts on the vertical axis. Use a zero baseline for these bars because lengths encode magnitude. A clear title describes the fictional sample; labels explain units. The scripts save PNG files so they work without a pop-up window.

## Worked model

The starter has already loaded `gaming.csv` as `df`, imported Pandas as `pd`, and defined the output folder `OUT`. Chart starters also import `plt`.

```python
counts = df["game"].value_counts().sort_index()
ax = counts.plot.bar(color="steelblue", rot=15)
ax.set(title="Games in the fictional club sample", xlabel="Game", ylabel="Players (count)")
ax.set_ylim(bottom=0)
plt.tight_layout()
plt.savefig(OUT / "lesson09_games.png")
plt.close()
print(counts)
```

Before running: predict one output. After running: explain one line to your partner. Python field names and game labels must match exactly.

## Your investigation

1. Predict bar heights from a table of counts, then create the chart.

2. Change the title and labels so a reader knows the sample and unit.

3. Write an accessible two-sentence description giving all three values and the main comparison.

## Support

Provide completed axes and a count table. Allow the description to be dictated or supplied as structured bullet points.

## Stretch

Create a chart of mean score by game using groupby. Explain why its vertical axis must change.

## Stop and check

Should the y-axis say score if the chart uses value_counts()?

## Save your evidence

Save your edited script and a short Markdown note containing your question, one result with units or denominator, an explanation of a key line, and any help used. For charts, include the PNG and a text description. Keep numerical results in your note rather than relying only on a screenshot.

## Exit ticket

State a question answered by your chart and one it does not answer.

