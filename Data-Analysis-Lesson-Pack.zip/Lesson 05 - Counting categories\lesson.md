﻿# Lesson 5: Counting categories

**Time:** 45 minutes · **Skills:** value_counts and percentages

## Learning intention

Summarise categorical data and state the denominator.

**Success criteria:** I can produce category counts and percentages and limit a claim to the sample.

## Get ready

[Starter Python](resources/starters/lesson05.py) · [CSV](resources/datasets/gaming.csv) · [Data dictionary](reference/data-dictionary.md)

Open the starter in your extracted pack. Save your own copy in the same starters folder with your initials in the filename. Run it using your editor, or `python resources/starters/lesson05.py` from the pack folder. Printed results appear in the terminal; saved files go to `resources/generated/`. See [setup](setup.md) if Python cannot find Pandas. Do not edit the raw CSV.

## Lesson route

| Minutes | Activity | What to do |
| --- | --- | --- |
| 0–5 | Retrieve and predict | Why can OR return more records than AND? |
| 5–13 | Model and explain | value_counts() counts occurrences of each value. A category count is not a mean score. normalise counts to proportions and multiply by 100 for percentages. Equal category sizes here are a feature of made-up teaching data. |
| 13–23 | Guided practice | Trace the model code, predict one output, then run it. Discuss the hinge question before progressing. |
| 23–38 | Apply independently | Complete the three core tasks. Save code and evidence; use support or stretch as appropriate. |
| 38–43 | Explain and review | Compare one result with a partner and justify a method or limitation. |
| 43–45 | Exit check | State one reason this sample cannot represent all Scottish young people. |

## Key idea

value_counts() counts occurrences of each value. A category count is not a mean score. normalise counts to proportions and multiply by 100 for percentages. Equal category sizes here are a feature of made-up teaching data.

## Worked model

The starter has already loaded `gaming.csv` as `df`, imported Pandas as `pd`, and defined the output folder `OUT`. Chart starters also import `plt`.

```python
counts = df["game"].value_counts()
print(counts)
print("Percent", df["game"].value_counts(normalize=True).mul(100).round(1))
```

Before running: predict one output. After running: explain one line to your partner. Python field names and game labels must match exactly.

## Your investigation

1. Predict which game is most common, then check all records rather than head().

2. Report the count and percentage for each game. State that the denominator is 30 players.

3. A poster says: Scotland’s favourite game is Sky Sprint. Rewrite the claim using only evidence in this table.

## Support

Use counters to model 10 out of 30 and a sentence frame: In this fictional sample, __ of __ records ___.

## Stretch

Filter to score >= 80 before counting games. Explain how the denominator changes.

## Stop and check

Do equal player counts imply equal average scores? Explain.

## Save your evidence

Save your edited script and a short Markdown note containing your question, one result with units or denominator, an explanation of a key line, and any help used. For charts, include the PNG and a text description. Keep numerical results in your note rather than relying only on a screenshot.

## Exit ticket

State one reason this sample cannot represent all Scottish young people.

